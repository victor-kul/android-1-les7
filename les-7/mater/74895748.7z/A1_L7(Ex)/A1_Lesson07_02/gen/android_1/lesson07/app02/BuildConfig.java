/** Automatically generated file. DO NOT MODIFY */
package android_1.lesson07.app02;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}