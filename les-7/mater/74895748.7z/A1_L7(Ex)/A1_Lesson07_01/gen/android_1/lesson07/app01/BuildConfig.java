/** Automatically generated file. DO NOT MODIFY */
package android_1.lesson07.app01;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}