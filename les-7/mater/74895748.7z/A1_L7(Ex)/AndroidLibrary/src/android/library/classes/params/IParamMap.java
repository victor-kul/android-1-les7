package android.library.classes.params;

public interface IParamMap {
	
	/** 
	 * Get value from a map by key.
	 * 	@param key (String) - name of a parameter 
	 * */
	public String get(String key);	
	
	/**
	 * Put value to a map by key.
	 * 	@param key (String) - name of a parameter
	 * 	@param value (String) - value of a parameter
	 * */
	public String put(String key, String value);
	
	/**
	 * Convert all key/value couples to string.
	 * 	@return All key/value couples as string.
	 * */
	public String toString();

}
