/*
 * Copyright (C) 2013 xDevStudio
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.   
 *  
 * */

package android.library.fragments;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;

@SuppressLint("NewApi")
public abstract class BaseFragment extends Fragment implements OnClickListener {
	
	/* Field for store a link to the OnClickListener object */
	private OnClickListener mOnClickListener = null;
	
	
	/*--------------------------------------------------------------------*/
	/* Methods for initialization this fragment 
	/*--------------------------------------------------------------------*/
	
	/** 
	 * Initializations user interface (UI) components. This method will invoke 
	 * into {@code onCreate}.
	 * */
	protected abstract void initUI(View view, Bundle savedInstanceState);
		
	/**
	 * Called immediately after {@link #onCreateView(LayoutInflater, ViewGroup, 
	 * Bundle)} has returned, but before any saved state has been restored in 
	 * to the view. This gives subclasses a chance to initialize themselves 
	 * once they know their view hierarchy has been completely created.  The 
	 * fragment's view hierarchy is not however attached to its parent at this 
	 * point. 
	 * */	
	@Override
	public void onViewCreated(View view, Bundle savedInstanceState) {
		
		/* Invoke a parent method */
		super.onViewCreated(view, savedInstanceState);		
		
		/* Initialization UI components */
		if (view != null) this.initUI(view, savedInstanceState);
		
	}
	
	
	/*--------------------------------------------------------------------*/
	/* Methods for working with view into this fragment
	/*--------------------------------------------------------------------*/	
	
	/**
	 * Look for a child view with the given id. If this view has the given id, 
	 * return this view.
	 * 
	 * @param id The id to search for.
	 * 
	 * @return The view that has the given id in the hierarchy or null.
	 *  
	 * */	
	public View findViewById(int id) {

		/* Get a link to root view */
		View v = this.getView();
		
		/* Find view by id */
		if (v != null) v = v.findViewById(id);
					
		/* Return view */
		return v;
		
	}
	
	
	/*--------------------------------------------------------------------*/
	/* Methods for working OnClickListener property
	/*--------------------------------------------------------------------*/
	
	/**
	 * Returns a link to the OnClickListener object that using in this or null.
	 * 
	 * @return A link to the OnClickListener object.
	 * 
	 */
	public OnClickListener getOnClickListener() {
		return mOnClickListener;
	}

	/**
	 * Sets a new value for the OnClickListener property.
	 * 
	 * @param value the new value of OnClickListener property
	 * 
	 */
	public void setOnClickListener(OnClickListener value) {
		mOnClickListener = value;
	}	
		
	/*--------------------------------------------------------------------*/
	/* Methods from OnClickListener interface
	/*--------------------------------------------------------------------*/	
	
	/**
     * Called when a view has been clicked.
     *
     * @param v The view that was clicked
     *  
     * */
	@Override
	public void onClick(View v) {		
		OnClickListener onClick = this.getOnClickListener();		
		if (onClick != null) onClick.onClick(v);			
	}		
	
}
