package android.library.web;

import java.io.IOException;
import java.io.InputStream;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;

import android.library.classes.StringArray;
import android.net.http.AndroidHttpClient;

/**
 * Class for send web request and receive answer from web server.
 * */

public class WebRequestor {	
	
	/** 
	 * Send web request and receive answer from web server.
	 * 	@param requestStr (String) - web request string
	 * 	@return Answer from a web server (as String).
	 * */
	public static String send(String requestStr) throws IOException {
		
		/* Input Stream */
		InputStream iStream = null;
		
		/* Result Strings (StringArray object) */
		StringArray resStrs = new StringArray();
	    
	    /* Make HTTP client object (AndroidHttpClient) */
		AndroidHttpClient httpClient = AndroidHttpClient.newInstance("WebClient");
		
		/* Make HTTP getter object (HttpGet) */
	    HttpGet httpGet = new HttpGet(requestStr);
	    
	    /* Make HTTP Response object (HttpResponse) */
	    HttpResponse httpResponse = httpClient.execute(httpGet);	    
	    
	    /* Get the input stream and convert it to a string */
	    try {
	    
	    	/* Getting the Input Stream from URLConnection object */
	    	iStream = httpResponse.getEntity().getContent();	    		    	    	
		    
	    	/* Convert the Input Stream to a String */
	    	resStrs.loadWithThrow(iStream, true);
	    	
	    } finally {
	    	
	    	/* Close Input Stream in any case */
	    	if (iStream != null) iStream.close();
	    	
	    	/* Abort HTTP getter connection */
	    	if (httpGet != null) httpGet.abort();	    	
	    	
	    	/* Close HTTP client object */
	    	if (httpClient != null) httpClient.close();	    		    
	    	
	    }	    	    	
	    
	    /* Return result strings */
	    return resStrs.toString();	   
				
	}		

}
