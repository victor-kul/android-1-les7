package android.library.fragments;

import android.library.app.R;
import android.library.sysutils.Clipboard;
import android.library.sysutils.SysConst;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

public class FrEditText extends BaseFragment {
	
	/* Field for store UI components */
	private EditText edText = null;
	
	/*--------------------------------------------------------------------*/
	/* Fragment LifeCycle methods 
	/*--------------------------------------------------------------------*/	

	/** 
	 * Initializations user interface (UI) components. This method will invoke 
	 * into {@code onCreate}.
	 * */	
	@Override
	protected void initUI(View view, Bundle savedInstanceState) {
		if (view instanceof EditText) 
			edText = (EditText) view;
		else
			throw new IllegalArgumentException("view is not EditText"); 
	}
	
	/** 
	 * Called to have the fragment instantiate its user interface view. This is 
	 * optional, and non-graphical fragments can return null (which is the 
	 * default implementation). This will be called between 
	 * {@code onCreate(Bundle)} and {@codeonActivityCreated(Bundle)}. 	
	 */		
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
				
		/* Register as callback for options menu */
		this.setHasOptionsMenu(true);
		
		/*  Inflate the layout for this fragment */
		View v = inflater.inflate(R.layout.fr_edit_text, container);
		
		/* Return a view */
		return v;
		
	}
	
	/*--------------------------------------------------------------------*/
	/* Methods for working with text into this fragment 
	/*--------------------------------------------------------------------*/	
	
	/**
	 * Returns a text from this fragment.
	 * */
	public String getText() {
		return edText.getText().toString();
	}
	
	/**
	 * Sets any text to this fragment.
	 * */
	public void setText(String text) {
		if (text != null) 
			edText.setText(text);
		else
			this.clear();
	}
	
	/**
	 * Clear text into this fragment.
	 * */
	public void clear() {
		edText.setText(SysConst.STR_EMPTY);
	}
	
	/*--------------------------------------------------------------------*/
	/* Methods for working with clip board 
	/*--------------------------------------------------------------------*/
	
	/**
	 * Copy text from this fragment to clip board.
	 * */
	public void copy() {
		Clipboard.put(getActivity(), getText());
	}	
	
	/*--------------------------------------------------------------------*/
	/* Menu LifeCycle methods
	/*--------------------------------------------------------------------*/	
	
	/**
	 * Initialize the contents of the Activity's standard options menu.  You
     * should place your menu items in to <var>menu</var>. 
	 * */	
	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		// Inflate the menu; this adds items to the action bar if it is present.
		inflater.inflate(R.menu.fr_edit_text_opt_menu, menu);
	}	
	
	/**
	 * This hook is called whenever an item in your options menu is selected. 
	 * */	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		/* Store Item id value */
		int id = item.getItemId();
		
		/* Menu "Copy" */
		if (id == R.id.fr_edit_text_m_copy) {
			this.copy();
			return true;
		}
		
		/** Example 1 (Example 2 see onOptionsItemSelected into Activity) */
		/* Menu "Clear" */
		if (id == R.id.fr_edit_text_m_clear) {
			this.clear();
			return true;
		}
		
		/* Return default value from super class */		
		return super.onOptionsItemSelected(item);
	}
	
	
}
