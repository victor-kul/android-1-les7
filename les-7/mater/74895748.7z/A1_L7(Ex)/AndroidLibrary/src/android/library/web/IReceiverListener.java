package android.library.web;

/**
 * Interface that described onReceive method
 * */

public interface IReceiverListener {
	
	/**
	 * Method for  call back interface 
	 * */
	public void onReceive(String resultStr);

}
