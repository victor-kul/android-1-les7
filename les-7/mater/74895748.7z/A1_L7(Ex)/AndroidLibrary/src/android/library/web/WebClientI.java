package android.library.web;

import android.library.sysutils.SysConst;

public class WebClientI extends WebClientA {
	
	/*---------------------------------------------------------------------------------------------------------------*/
	/* Private fields
	/*---------------------------------------------------------------------------------------------------------------*/
	
	/* Private field for store link to IReceiveListener object */
	private IReceiverListener fReceiverListener = null;

	
	/*---------------------------------------------------------------------------------------------------------------*/
	/* Constructors with and without parameters
	/*---------------------------------------------------------------------------------------------------------------*/	
	
	/**
	 * Constructor without any parameters. The default value "" (empty string) will used for web request string
	 * and the WebRequest object will be created automatically.  
	 * */		
	public WebClientI() { this(SysConst.STR_EMPTY); }
		
	/**
	 * Constructor with parameter that described web request string. The WebRequest object will be 
	 * created automatically.
	 * 	@param requestStr (String) - web request string without parameters. 
	 * */
	public WebClientI(String requestStr) { super(requestStr); }
		
	/**
	 * Constructor with parameter that described web request object (WebRequest) that will using for
	 * sending requests to a web server.
	 * 	@param webRequest (WebRequest) - web request object
	 * */
	public WebClientI(WebRequest webRequest) { super(webRequest); }
	
	
	/*---------------------------------------------------------------------------------------------------------------*/
	/* Property ReceiverListener  
	/*---------------------------------------------------------------------------------------------------------------*/
	
	/**
	 * Get current IReceiverListener object.
	 * 	@return Current IReceiverListener object.
	 * */
	public IReceiverListener getReceiverListener() { return fReceiverListener; }
	
	/**
	 * Set IReceiverListener for this object
	 * 	@param iReceiverListener - IReceiverListener object that will use as ReceiverListener for this 
	 * */
	public void setReceiverListener(IReceiverListener iReceiverListener) { fReceiverListener = iReceiverListener; }

	
	/*---------------------------------------------------------------------------------------------------------------*/
	/* Methods for callback interface to asynchronous task 
	/*---------------------------------------------------------------------------------------------------------------*/	
	/**
	 * Execute after the answer from a web server will be received. This method uses IReceiverListener interface.
	 * 	@param resultStr (String) - answer from a web server or error message.
	 * */	
	@Override
	public void onReceive(String resultStr) { 
		if (fReceiverListener != null) fReceiverListener.onReceive(resultStr);
	}

}
