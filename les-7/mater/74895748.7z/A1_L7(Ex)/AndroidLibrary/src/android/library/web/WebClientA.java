package android.library.web;

import java.io.IOException;

import android.library.sysutils.SysConst;
import android.os.AsyncTask;

/**
 * Class that works as web client. You can send request to a web server (as string) and receive result.  
 * */

public abstract class WebClientA {
	
	/*---------------------------------------------------------------------------------------------------------------*/
	/* Private fields
	/*---------------------------------------------------------------------------------------------------------------*/	
	private WebRequest fWebRequest = null;
	

	/*---------------------------------------------------------------------------------------------------------------*/
	/* Constructors with and without parameters
	/*---------------------------------------------------------------------------------------------------------------*/
		
	/**
	 * Constructor without any parameters. The default value "" (empty string) will used for web request string
	 * and the WebRequest object will be created automatically.  
	 * */
	public WebClientA() { this(SysConst.STR_EMPTY); }	
		
	/**
	 * Constructor with parameter that described web request string. The WebRequest object will be 
	 * created automatically.
	 * 	@param requestStr (String) - web request string without parameters. 
	 * */
	public WebClientA(String requestStr) { this(new WebRequest(requestStr)); }
	
	/**
	 * Constructor with parameter that described web request object (WebRequest) that will using for
	 * sending requests to a web server.
	 * 	@param webRequest (WebRequest) - web request object
	 * */
	public WebClientA(WebRequest webRequest) { super(); setWebRequest(webRequest); }
	
	
	/*---------------------------------------------------------------------------------------------------------------*/
	/* Property WebRequest: WebRequest 
	/*---------------------------------------------------------------------------------------------------------------*/	
	
	/**
	 * Get current WebRequest object.
	 * 	@return WebRequest object that using now. 
	 * */
	public WebRequest getWebRequest() { return fWebRequest; }

	/**
	 * Set current WebRequest object.
	 * 	@param value (WebRequest) - object that will use as WebRequest
	 * */
	public void setWebRequest(WebRequest value) { fWebRequest = value; }		
	
	/*---------------------------------------------------------------------------------------------------------------*/
	/* Methods for callback interface to asynchronous task 
	/*---------------------------------------------------------------------------------------------------------------*/	
	
	/**
	 * Abstract method. Execute after the answer from a web server will be received. Override this method and
	 * put your code for processing web server answer.
	 * 	@param resultStr (String) - answer from a web server or error message.
	 * */
	public abstract void onReceive(String resultStr);

	
	/*---------------------------------------------------------------------------------------------------------------*/
	/* Send request to a web server 
	/*---------------------------------------------------------------------------------------------------------------*/
	
	/** 
	 * Send the request to a web server. This method uses WebRequest object for make a web request string.
	 * If WebRequest is equal null, the empty string will use as web request string.  
	 * */
	public void send() {
		
		if (this.getWebRequest() != null)		
			this.send(this.getWebRequest().makeRequest());
		else
			this.send(SysConst.STR_EMPTY);
		
	}	
	
	/**
	 * Send the request to a web server.
	 * 	@param requestStr (String) - request string to a web server.
	 * */
	public void send(String requestStr) { new AsyncRequestObject().execute(requestStr); }

	/*---------------------------------------------------------------------------------------------------------------*/
	/* Private class for execute asynchronous task
	/*---------------------------------------------------------------------------------------------------------------*/
	
	private class AsyncRequestObject extends AsyncTask<String, Integer, String> {

		/* This code execute in background thread */
		@Override
		protected String doInBackground(String... params) { 				
			try {
				return WebRequestor.send(params[0]);
			} catch (IOException e) {
				return e.getMessage();
			}					
		}		
		
        /* This code execute after doInBackground */
		@Override
        protected void onPostExecute(String result) { onReceive(result); }       
        
	}			
	
}
