package android.library.location;

import android.app.Activity;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

/**
 * Activity for working with location service.
 * */
public class LocActivity extends Activity implements LocationListener {
			
	/* Field for store a link to the location listener object */
	private LocListener locListener = null;		
	
	/*--------------------------------------------------------------------*/
	/* Activity Life Cycle methods 
	/*--------------------------------------------------------------------*/	
	
    /**
     * Called as part of the activity life cycle when an activity is going into
     * the background, but has not (yet) been killed.  The counterpart to
     * {@code onResume}. 
     * */
	@Override
	protected void onPause() {

		/* Removes any current registration for location updates */
		if (locListener != null && this.isLocUpdating()) {
			LocManager.removeUpdates(this, locListener);
		}
		
		/* Invoke a parent method */
		super.onPause();
	}
	
    /**
     * Called after {@code onCreate} or after {@code onRestart} when  
     * the activity had been stopped, but is now again being displayed to the 
	 * user.  It will be followed by {@code onResume}. 
	 * */		
	@Override
	protected void onStart() {		
		
		/* Invoke a parent method */
		super.onStart();
		
		if (this.getAutoStartLocRequest()) {
		
			/* Create location listener, if needed */
			if (locListener == null) locListener = new LocListener();
		
			/* Restore any current registration for location updates */
			LocManager.requestLocationUpdates(this, this.getUsingMinTime(), 
					this.getUsingMinDistance(), locListener, 
					this.getUsingProviders());
		}		
	}	
	
	/*--------------------------------------------------------------------*/
	/* Location parameter - MinTime property  
	/*--------------------------------------------------------------------*/
	
	/* 
	 * Private field for store minimum time interval between location updates 
	 * */
	private long mUsingMinTime = MIN_TIME_DELTA;	
	
	/**
	 * Default value for minimum time interval between location updates, in 
     * milliseconds.
	 * */
	public static final long MIN_TIME_DELTA = 0L;
	
	/**
	 * Returns minimum time interval between location updates (in milliseconds)
	 * that using now.
	 * 
	 * @return The value of current minimum time interval between location 
	 * updates, in milliseconds.
	 * 
	 * */
	public long getUsingMinTime() { return  mUsingMinTime; }
	
	/**
	 * Sets a new value of minimum time interval between location updates (in 
	 * milliseconds) that will using.
	 * 
	 * @param value the new value of minimum time interval between location 
	 * updates, in milliseconds, if value < 0, the {@code MIN_TIME_DELTA} will
	 * use
	 * 
	 * */
	public void setUsingMinTime(long minTime) {
		
		if (minTime < 0L) 
			mUsingMinTime = MIN_TIME_DELTA;
		else
			mUsingMinTime = minTime;
			
	}
	

	/*--------------------------------------------------------------------*/
	/* Location parameter - MinDistance property  
	/*--------------------------------------------------------------------*/
	
	/* 
	 * Private field for store minimum distance between location updates 
	 * */
	private float mUsingMinDistance = MIN_DISTANCE_DELTA;	
	
	/**
	 * Default value for minimum distance between location updates, in meters
	 * */
	public static final float MIN_DISTANCE_DELTA = 0f;
	
	
	/**
	 * Returns minimum distance between location updates (in meters) that using 
	 * now.
	 * 
	 * @return The value of current minimum distance between location updates, 
	 * in meters
	 * 
	 * */
	public float getUsingMinDistance() { return  mUsingMinDistance; }
	
	/**
	 * Sets a new value of minimum distance between location updates (in meters) 
	 * that will using.
	 * 
	 * @param value the new value of minimum distance between location updates, 
	 * in meters, if value < 0, the {@code MIN_DISTANCE_DELTA} will use
	 * 
	 * */
	public void setUsingMinDistance(float minDistance) {
		
		if (minDistance < 0f) 
			mUsingMinDistance = MIN_TIME_DELTA;
		else
			mUsingMinDistance = minDistance;
			
	}	
		
	
	/*--------------------------------------------------------------------*/
	/* Location parameter - Providers property 
	/*--------------------------------------------------------------------*/
	
	/* 
	 * Private field for store the names of the providers with which to 
	 * register location updates 
	 * */	
	private String[] mUsingProviders = {LocationManager.NETWORK_PROVIDER, 
			LocationManager.GPS_PROVIDER};	
		
	/**
	 * Returns the names of the providers with which to register of location
	 * updates, now.
	 * 
	 * @return The string array that contains names of providers with which to 
	 * register of location updates, now. 
	 * 
	 * */
	public String[] getUsingProviders() { 		
		return mUsingProviders.clone(); 		
	}

	/**
	 * Sets a new providers to register of location updates.
	 * */
	public void setUsingProviders(String... providers) {
		mUsingProviders = providers.clone();
	}	
		
	
	/*--------------------------------------------------------------------*/
	/* Auto update location request property 
	/*--------------------------------------------------------------------*/

	/*
	 * Private field for store a value for "AutoUpdateLocationRequest" property. 
	 * If this is equal true, the location updates request will update 
	 * automatically after change any location update parameters. 
	 * */
	private boolean mAutoUpdateLocRequest = false;
		
	/**
	 * Returns a value for the "AutoUpdateLocationRequest" property.
	 * */
	public boolean isAutoUpdateLocRequest() {
		return mAutoUpdateLocRequest;
	}

	/**
	 * Sets the new value for "AutoUpdateLocationRequest" property.
	 * */
	public void setAutoUpdateLocRequest(boolean value) {
		mAutoUpdateLocRequest = value;		
	}	
	
	
	/*--------------------------------------------------------------------*/
	/* Auto start location request property 
	/*--------------------------------------------------------------------*/
	
	/*
	 * Private field for store a value for the AutoStartLocRequest property.  
	 * */
	private boolean mAutoStartLocRequest = true;
	
	/**
	 * Returns a value for the AutoStartLocRequest property. This property 
	 * describes ability start receive location updates on startup Activity, or 
	 * not.
	 * */
	public boolean getAutoStartLocRequest() {
		return mAutoStartLocRequest;
	}
	
	
	/*--------------------------------------------------------------------*/
	/* Receive Location Update - Providers property 
	/*--------------------------------------------------------------------*/
	
	/*
	 * Private field for store a value for "LocUpdating" property.  
	 * */
	private boolean mLocUpdating = true;
	
	/**
	 * Returns a value for "LocUpdating" property. If it is equal
	 * true, the location updates receive now.
	 * */
	public boolean isLocUpdating() {
		return mLocUpdating;
	}	
	
	
	/*--------------------------------------------------------------------*/
	/* Methods for working with request location updates parameters 
	/*--------------------------------------------------------------------*/	
	
	public void setLocationUpdateParameters(long minTime) {}	
	public void setLocationUpdateParameters(float minDistance) {}		
	public void setLocationUpdateParameters(String... providers) {}			
	public void setLocationUpdateParameters(long minTime, float minDistance) {}		
	public void setLocationUpdateParameters(long minTime, float minDistance, 
			String... providers) {}		
	public void updateLocationRequest() {}
	
	/*--------------------------------------------------------------------*/
	/* Location service methods 
	/*--------------------------------------------------------------------*/	
		
	/**
	 * Class that store call back method for LocationListener interface
	 * */
	private class LocListener implements LocationListener {
		
		@Override
		public void onLocationChanged(Location location) {
			LocActivity.this.onLocationChanged(location);
		}
		@Override
		public void onStatusChanged(String provider, int status, Bundle extras){
			LocActivity.this.onStatusChanged(provider, status, extras);
		}
		
		@Override
		public void onProviderEnabled(String provider) {
			LocActivity.this.onProviderEnabled(provider);
		}
		
		@Override
		public void onProviderDisabled(String provider) {
			LocActivity.this.onProviderDisabled(provider);
		}

	}
		
	/*--------------------------------------------------------------------*/
	/* Methods from interface LocationListener 
	/*--------------------------------------------------------------------*/	

	@Override
	public void onLocationChanged(Location location) {}

	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {}

	@Override
	public void onProviderEnabled(String provider) {}

	@Override
	public void onProviderDisabled(String provider) {}
	
}
