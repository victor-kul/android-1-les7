package android.library.web;

import java.net.URL;
import java.net.MalformedURLException;

import android.library.classes.params.IParamMap;
import android.library.classes.params.ParamMap;
import android.library.classes.params.ParamType;
import android.library.sysutils.SysConst;

/**
 * Class for a building the request string (with or without parameters). You could use custom ParamMap object.
 * */

public class WebRequest {
	
	/*---------------------------------------------------------------------------------------------------------------*/
	/* Private fields 
	/*---------------------------------------------------------------------------------------------------------------*/
	
	/* Private field for store a ParamMap object */
	private IParamMap iParamMap = null;
	
	
	/*---------------------------------------------------------------------------------------------------------------*/
	/* Constructors with and without parameters:
	/*---------------------------------------------------------------------------------------------------------------*/
		
	/**
	 * Constructor with parameters that described web request string.
	 * 	@param requestStr (String) - web request string
	 * */
	public WebRequest(String requestStr) { this(requestStr, ParamMap.Factory.Create(ParamType.HTTP)); }
	
	/**
	 * Constructor with parameters that described web request string and object that
	 * will be using as ParamMap object.
	 * 	@param requestStr (String) - web request string
	 * 	@param iParamMap (IParamMap) - object that implements interface iParamMap
	 * */
	public WebRequest(String requestStr, IParamMap iPparamMap) { 
		
		/* Invoke parent constructor */
		super();
		
		/* Setting up web request string value */
		this.setRequestStr(requestStr);
		
		/* Setting up link to the iParamMap object */
		this.iParamMap = iPparamMap; 
		
	}

	
	/*---------------------------------------------------------------------------------------------------------------*/
	/* Property RequestStr: String
	/*---------------------------------------------------------------------------------------------------------------*/
	
	/* Private field for store a request string */
	private String fRequestStr = SysConst.STR_EMPTY;
	
	/**
	 * Get a request string value.
	 * 	@return Request string that using now. 
	 * */
	public String getRequestStr() { return fRequestStr; }
	
	/**
	 * Set a request string value.
	 * 	@param value (String) - new value for request string
	 * */
	public void setRequestStr(String value) { fRequestStr = value; }
	

	/*---------------------------------------------------------------------------------------------------------------*/
	/* Get current ParamMap object 
	/*---------------------------------------------------------------------------------------------------------------*/
	
	/**
	 * Get object that using as ParamMap. If this object did not exists before, it will be created.
	 *	@return Object that using as ParamMap, now.
	 * */
	public IParamMap getParams() { return iParamMap; }
	
	
	/*---------------------------------------------------------------------------------------------------------------*/
	/* Methods for working with parameters (key/value couples)  
	/*---------------------------------------------------------------------------------------------------------------*/
	
	/**
	 * Get parameter value from a map by name.
	 * */
	public String getParam(String key) { 		
		
		if(this.getParams() != null)
			return this.getParams().get(key);
		else
			return null;
		
	}
		
	/**
	 * Put parameter value to a map by name.
	 * */
	public String putParam(String key, String value) { return this.getParams().put(key, value); }
	
	
	/*---------------------------------------------------------------------------------------------------------------*/
	/* Make string that includes request string and parameters string.   
	/*---------------------------------------------------------------------------------------------------------------*/
	
	/**
	 * Make string that includes request string and parameters string.
	 * */
	public String makeRequest() {	
		
		if (this.getParams() != null)
			return this.getRequestStr() + this.getParams().toString();
		else
			return this.getRequestStr();
		
	}
	
	
	/*---------------------------------------------------------------------------------------------------------------*/
	/* Get URL object by web request string   
	/*---------------------------------------------------------------------------------------------------------------*/
			
	/** 
	 * Get URL object by web request string.
	 * 	@return URL object or null if incorrect URL specification was issued.  
	 * */
	public URL getURL() {
		
		try {
			return WebRequest.getURL(this.makeRequest());
		} catch (MalformedURLException e) {
			e.printStackTrace();
			return null;
		}
			
	}
	
	/** 
	 * Static method - get URL object by Request String 
	 * @throws MalformedURLException - This exception is thrown when a program attempts to create an URL from an
	 * incorrect specification  
	 * */
	public static URL getURL(String requestStr) throws MalformedURLException  { return new URL(requestStr); }
	
}
