/** 
 * 
 * Mikhail Malakhov
 *   
 * */

package android.library.classes.params;

import java.util.HashMap;

import android.library.sysutils.SysConst;
import android.net.Uri;

/**
 * Class for working with map of parameters (key/value couples). This class extends HashMap<String, String>.   
 * You could select any string as prefix for parameters string, separator between key/value couples, any string 
 * as equal between keys and values, and string that using as suffix in parameters string. Also, you could use 
 * type of parameters (<i>ParamType</i> object) for create object with some standards values.   
 *	@author Mikhail Malakhov
 * */

public class ParamMap extends HashMap<String, String> implements IParamMap {				
	
	/*---------------------------------------------------------------------------------------------------------------*/
	/* Private fields
	/*---------------------------------------------------------------------------------------------------------------*/
	
	/* Constant from Super Class */
	private static final long serialVersionUID = 1L;	
	
	
	/*---------------------------------------------------------------------------------------------------------------*/
	/* Constructors with and without parameters:
	/*
	/*	ParamMap()
	/*  ParamMap(ParamType paramType)
	/*  ParamMap(String equalStr, String seprtStr)
	/*  ParamMap(String prfixStr, String equalStr, String seprtStr)
	/*  ParamMap(String prfixStr, String equalStr, String seprtStr, String sufixStr)		
	/*
	/*  ParamMap(int capacity)	
	/*  ParamMap(int capacity, ParamType paramType)
	/*  ParamMap(int capacity, String equalStr, String seprtStr)
	/*  ParamMap(int capacity, String prfixStr, String equalStr, String seprtStr)
	/*  ParamMap(int capacity, String prfixStr, String equalStr, String seprtStr, String sufixStr)
	/* 	
	/*---------------------------------------------------------------------------------------------------------------*/	
	
	/** 
	 * Constructor without any parameters. This constructor creates ParamMap object with default values. 
	 * */
	public ParamMap() { super(); }
		
	/** 
	 * Constructor with parameter that described type of parameters.
	 * 	@param paramType (ParamType) - type of parameters.
	 */
	public ParamMap(ParamType paramType) { 
		this(paramType.getPrfixStr(), paramType.getEqualStr(), paramType.getSeprtStr(), paramType.getSufixStr());		
	}	

	/** 
	 * Constructor with parameters that described strings that using as equal and separator.
	 * 	@param equalStr (String) - string that using as equal between keys and values
	 * 	@param seprtStr (String) - string that using as separator between key/value couples   
	 *  */
	public ParamMap(String equalStr, String seprtStr) { this(); setEqualStr(equalStr); setSeprtStr(seprtStr); }
	
	/** 
	 * Constructor with parameters that described strings that using as prefix, equal and separator.
	 * 	@param prfixStr (String) - string that using as prefix for parameters string
	 * 	@param equalStr (String) - string that using as equal between keys and values
	 * 	@param seprtStr (String) - string that using as separator between key/value couples   
	 *  */
	public ParamMap(String prfixStr, String equalStr, String seprtStr) { 
		this(equalStr, seprtStr); setPrfixStr(prfixStr);
	}
	
	/** 
	 * Constructor with parameters that described strings that using as equal and separator.
	 * 	@param prfixStr (String) - string that using as prefix for parameters string
	 * 	@param equalStr (String) - string that using as equal between keys and values
	 * 	@param seprtStr (String) - string that using as separator between key/value couples   
	 * 	@param sufixStr (String) - string that using as suffix for parameters string
	 *  */	
	public ParamMap(String prfixStr, String equalStr, String seprtStr, String sufixStr) {
		this(prfixStr, equalStr, seprtStr); setSufixStr(sufixStr);
	}	
	
	/**
	 * Constructor with one parameter (capacity, from super class).
	 * 	@param capacity (int) - the initial capacity of this object
	 * */
	public ParamMap(int capacity) { super(capacity); }	
	
	/** 
	 * Constructor with parameters that described one parameter from super class (capacity) and type of parameters.
	 * 	@param capacity (int) - the initial capacity of this object
	 * 	@param paramType (ParamType) - type of parameters
	 */
	public ParamMap(int capacity, ParamType paramType) { 
		this(capacity, paramType.getPrfixStr(), paramType.getEqualStr(), paramType.getSeprtStr(), 
				paramType.getSufixStr());		
	}		
			
	/** 
	 * Constructor with parameters that described one parameter from super class (capacity) and strings that using
	 * as separator and equal.  
	 *  @param capacity (int) - the initial capacity of this object 
	 * 	@param equalStr (String) - string that using as equal between keys and values
	 * 	@param seprtStr (String) - string that using as separator between key/value couples   
	 * */	
	public ParamMap(int capacity, String equalStr, String seprtStr) {			
		this(capacity);	setEqualStr(equalStr); setSeprtStr(seprtStr);
	}	
	
	/** 
	 * Constructor with parameters that described one parameter from super class (capacity) and strings that using
	 * as prefix, separator and equal.  
	 *  @param capacity (int) - the initial capacity of this object 
	 *  @param prfixStr (String) - string that using as prefix for parameters string
	 * 	@param equalStr (String) - string that using as equal between keys and values
	 * 	@param seprtStr (String) - string that using as separator between key/value 
	 * 	couples   
	 * */	
	public ParamMap(int capacity, String prfixStr, String equalStr, String seprtStr) {			
		this(capacity, equalStr, seprtStr); setPrfixStr(prfixStr); 	
	}	
	
	/** 
	 * Constructor with parameters that described one parameter from super class (capacity) and strings that using
	 * as prefix, separator, equal and suffix. 
	 * 	@param capacity (int) - the initial capacity of this object
	 * 	@param prfixStr (String) - string that using as prefix for parameters string
	 * 	@param equalStr (String) - string that using as equal between keys and values
	 * 	@param seprtStr (String) - string that using as separator between key/value couples   
	 * 	@param sufixStr (String) - string that using as suffix for parameters string
	 *  */	
	public ParamMap(int capacity, String prfixStr, String equalStr, String seprtStr, String sufixStr) {
		this(capacity, prfixStr, equalStr, seprtStr); setSufixStr(sufixStr);
	}
	
	
	/*--------------------------------------------------------------------------------------------------------------*/
	/* Property PrfixStr: String                            
	/*--------------------------------------------------------------------------------------------------------------*/
	
	/* Private field for store a string that using as prefix for parameters string */
	private String fPrfixStr = SysConst.STR_EMPTY;
	
	/**
	 * Get string that using as prefix for parameters string (current value).
	 * @return String that using as prefix for parameters string, now.
	 * */
	public String getPrfixStr() { return fPrfixStr; }
		
	/**
	 * Set new value of string that using as prefix for parameters string.
	 * @param value (String) - new value string that using as prefix for parameters string.
	 * */	
	public void setPrfixStr(String value) { fPrfixStr = value; }	
	
	
	/*--------------------------------------------------------------------------------------------------------------*/
	/* Property EqualStr: String
	/*--------------------------------------------------------------------------------------------------------------*/
	
	/* Private field for store a string that using as equal between keys and values  */
	private String fEqualStr = SysConst.STR_EQUAL;
	
	/**
	 * Get string that using as equal between keys and values (current value).
	 * 	@return String that using as equal between keys and values, now.
	 * */
	public String getEqualStr() { return fEqualStr; }
	
	/**
	 * Set new value of string that using as equal between keys and values.
	 * 	@param value (String) - new value of string that using as equal between keys and values
	 * */
	public void setEqualStr(String value) { fEqualStr = value; }	
	
	
	/*--------------------------------------------------------------------------------------------------------------*/
	/* Property SeprtStr: String
	/*--------------------------------------------------------------------------------------------------------------*/	
	
	/* 
	 * Private field for store a string that using as separator between key/value couples  
	 * */  
	private String fSeprtStr = SysConst.STR_SEPRT;
	
	/**
	 * Get string that using as separator between key/value couples (current value).
	 * 	@return String that using as separator between key/value couples, now. 
	 * */
	public String getSeprtStr() { return fSeprtStr; }
	
	/**
	 * Set new value of string that using as separator between key/value couples.
	 * 	@param value (String) - new value of string that using as separator between key/value couples
	 * */
	public void setSeprtStr(String value) { fSeprtStr = value; }
	
	
	/*--------------------------------------------------------------------------------------------------------------*/
	/* Property SufixStr: String                            
	/*--------------------------------------------------------------------------------------------------------------*/
	
	/* Private field for store a string that using as suffix for parameters string */
	private String fSufixStr = SysConst.STR_EMPTY;
	
	/**
	 * Get string that using as suffix for parameters string (current value).
	 * @return String that using as suffix for parameters string, now.
	 * */
	public String getSufixStr() { return fSufixStr; }
		
	/**
	 * Set new value of string that using as suffix for parameters string.
	 * @param value (String) - new value string that using as suffix for parameters string.
	 * */	
	public void setSufixStr(String value) { fSufixStr = value; }
	
	
	/*--------------------------------------------------------------------------------------------------------------*/
	/* Method get (get value from a map)
	/*--------------------------------------------------------------------------------------------------------------*/
	
	@Override
	/** Get value from a map by key. */
	public String get(String key) { return super.get(key); }		
	
	
	/*--------------------------------------------------------------------------------------------------------------*/
	/* Method put (put value to a map) and call back interface
	/*--------------------------------------------------------------------------------------------------------------*/	
		
	/* Override the put method for implementation call back interface of put processing */
	@Override
	public String put(String key, String value) {return super.put(key, this.onPut(key, value));}	
	
	/**
	 * Implementing callback interface for put processing. You could override this method to control values during
	 * put processing.
	 *	@param key (String) - key string
	 * 	@param value (String) - value string
	 * 	@return value that will put to map.   
	 * */
	protected String onPut(String key, String value) { return value; }	
		
	/**
	 * Put integer value by key. Before put processing, this integer value will be converted to String.
	 * 	@param key (String) - key string
	 * 	@param value (int) - integer value
	 * */
	public String put(String key, int value) { return this.put(key, String.valueOf(value)); }
	
	
	/*--------------------------------------------------------------------------------------------------------------*/
	/* Convert all key/value couples to string
	/*--------------------------------------------------------------------------------------------------------------*/
						
	/** 
	 * Convert all key/value couples to string. 
	 *	@return All key/value couples as string.
	 * */	
	@Override
	public String toString() {		
		return ParamMap.toString(this, getPrfixStr(), getEqualStr(), getSeprtStr(), getSufixStr());		
	}		
	
	/**
	 * Convert all key/value couples to string.
	 * 	@param equalStr - string that using as equal between keys and values
	 * 	@param seprtStr - string that using as separator between key/value couples   
	 *  @return All key/value couples as string.
	 * */	
	public String toString(String equalStr, String seprtStr) { 
		return ParamMap.toString(this, equalStr, seprtStr); 
	}
	
	/**
	 * Convert all key/value couples to string.
	 * 	@param prfixStr - string that using as prefix for parameters string
	 * 	@param equalStr - string that using as equal between keys and values
	 * 	@param seprtStr - string that using as separator between key/value couples   
	 *  @return All key/value couples as string.
	 * */	
	public String toString(String prfixStr, String equalStr, String seprtStr) {
		return ParamMap.toString(this, equalStr, seprtStr);
	}
	
	/** 
	 * Static Method. Convert all key/value couples to string.
	 * 	@param prfixStr - string that using as prefix for parameters string 
	 * 	@param equalStr - string that using as equal between keys and values
	 * 	@param seprtStr - string that using as separator between key/value couples
	 * 	@param sufixStr - string that using as suffix for parameters string   
	 *  @return All key/value couples as string.
	 *  */
	public String toString(String prfixStr, String equalStr, String seprtStr, String sufixStr) {
		return ParamMap.toString(this, prfixStr, equalStr, seprtStr, sufixStr);
	}
		
	
	/*--------------------------------------------------------------------------------------------------------------*/
	/* Convert keys, values and key/value couples to string array
	/*--------------------------------------------------------------------------------------------------------------*/
	
	/**
	 * Convert all keys to String array.
	 * 	@return String array contains all keys.
	 * */
	public String[] getKeys() { return (String[]) this.keySet().toArray(); }
	
	/** 
	 * Convert all values to String array. 
	 * 	@return String array contains all values.
	 * */
	public String[] getValues() { return (String[]) this.values().toArray(); }
	
	/**
	 * Convert all couples of key/value to String Array.
	 * 	@return Array of string that contains all key/value couples.  
	 * */
	public String[] toArray() { return this.toArray(getEqualStr()); }
	
	/**
	 * Convert all couples of key/value to String Array.
	 * 	@param equalStr - string that using as equal between keys and values
	 * 	@return Array of string that contains all key/value couples.  
	 * */
	public String[] toArray(String equalStr) { return ParamMap.toArray(this, equalStr); }
	
	
	/*--------------------------------------------------------------------------------------------------------------*/
	/* Static Method - convert all key/value couples to string
	/*--------------------------------------------------------------------------------------------------------------*/
	
	/** 
	 * Static Method. Convert all key/value couples to string.
	 * 	@param hashMap - map(String, String) of parameters that need to convert to string 
	 * 	@param equalStr - string that using as equal between keys and values
	 * 	@param seprtStr - string that using as separator between key/value couples   
	 *  @return All key/value couples as string.
	 *  */
	public static String toString(HashMap<String, String> hashMap, String equalStr, String seprtStr) {		
		return ParamMap.toString(hashMap, SysConst.STR_EMPTY, equalStr, seprtStr, SysConst.STR_EMPTY);
	}	
	
	/** 
	 * Static Method. Convert all key/value couples to string.
	 * 	@param hashMap - map(String, String) of parameters that need to convert to string
	 * 	@param prfixStr - string that using as prefix for parameters string 
	 * 	@param equalStr - string that using as equal between keys and values
	 * 	@param seprtStr - string that using as separator between key/value couples   
	 *  @return All key/value couples as string.
	 *  */
	public static String toString(HashMap<String, String> hashMap, String prfixStr, String equalStr, 
			String seprtStr) {		
		return ParamMap.toString(hashMap, prfixStr, equalStr, seprtStr, SysConst.STR_EMPTY);
	}
	
	/** 
	 * Static Method. Convert all key/value couples to string.
	 * 	@param hashMap - map(String, String) of parameters that need to convert to string
	 * 	@param prfixStr - string that using as prefix for parameters string 
	 * 	@param equalStr - string that using as equal between keys and values
	 * 	@param seprtStr - string that using as separator between key/value couples
	 * 	@param sufixStr - string that using as suffix for parameters string   
	 *  @return All key/value couples as string.
	 *  */
	public static String toString(HashMap<String, String> hashMap, String prfixStr, String equalStr, 
			String seprtStr, String sufixStr) {

		/* Create StringBuilder object for build a Parameters string */
		StringBuilder StrBuilder = new StringBuilder(hashMap.size());
		
		/* Build a Parameters string */
		for (String key: hashMap.keySet()) 
			StrBuilder.append(key + equalStr + hashMap.get(key) + seprtStr);
		
		/* Get result string length */
		int Length = StrBuilder.length();
		
		/* if Length > 0, delete last char */
		if (Length > 0)
			return prfixStr + StrBuilder.toString().substring(0, Length - 1) + sufixStr;
		else
			return SysConst.STR_EMPTY;
		
	}	

	/*--------------------------------------------------------------------------------------------------------------*/
	/* Static Method - convert all couples of key/value to String Array
	/*--------------------------------------------------------------------------------------------------------------*/
		
	/**
	 * Static method. Convert all couples of key/value to String Array.
	 *	@param hashMap - map(String, String) of parameters that need to convert to String Array
	 * 	@param equalStr - string that using as equal between keys and values
	 * 	@return Array of string that contains all key/value couples.
	 * */
	public static String[] toArray(HashMap<String, String> hashMap, String equalStr) {
		
		/* Create array of String */
		String[] array = new String[hashMap.keySet().size()];
		
		/* Variable that using as counter */
		int i = 0;
		
		/* Filling array of string */
		for (String key: hashMap.keySet()) 
			array[i++] = key + equalStr + hashMap.get(key);	
		
		/* Return value */
		return array;
	}
	
	
	/*--------------------------------------------------------------------------------------------------------------*/
	/* Public static class Factory
	/*--------------------------------------------------------------------------------------------------------------*/	
	
	/**
	 * Static class Factory - class for create ParamMap object by ParamType.  
	 * */
	public static class Factory {
		
		/** 
		 * Static Method - create ParamMap object by type of parameters (ParamType) 
		 * @param paramType - type of parameters
		 * @return ParamMap object 	
		 * */	
		public static ParamMap Create(ParamType paramType) {
			
			/* if paramType is null, return ParamMap object from default constructor */
			if (paramType == null) return new ParamMap();
					
			/* switch paramType */
			switch (paramType) {
			
				/* HTTP ParamMap */
				case HTTP: 
										
					return new ParamMap(paramType) {
						private static final long serialVersionUID = 1L;
						@Override
						protected String onPut(String key, String value) { return Uri.encode(value); }						
					};
										
				/* Default constructor */
				default:  return new ParamMap(paramType);
					
			}
			
		}			
		

	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
		
}