package android.library.classes.params;

import android.library.sysutils.SysConst;

/**
 * Enum that contain information about type of parameters. Type of parameters (key/value couples) that using in 
 * the ParamMap object. 
 * 	@since <b>INI</b> - Parameters looks like *.ini file (key1=value1)
 * 	@since <b>CVS</b> - Parameters looks like *.cvs file (key1,value1,key2,value2)
 * 	@since <b>HTTP</b> - Parameters looks like HTTP request (key1=value1&key2=value2)
 * 	@since <b>XML</b> - Parameters looks like *.xml file (key1="value1" key2="value2")    
 * 	@author Mikhail Malakhov
 * */

public enum ParamType {

	/*--------------------------------------------------------------------------------------------------------------*/
	/* Values 
	/*--------------------------------------------------------------------------------------------------------------*/	
	
	/** Parameters looks like *.ini file (<i>key1=value1</i>). */
	INI(SysConst.STR_EMPTY, SysConst.STR_EQUAL, SysConst.STR_NEWLN, SysConst.STR_EMPTY), 
	
	/** Parameters looks like *.cvs file (<i>key1,value1,key2,value2</i>). */
	CVS(SysConst.STR_EMPTY, SysConst.STR_SEPRT, SysConst.STR_SEPRT, SysConst.STR_EMPTY),
	
	/** Parameters looks like HTTP request (<i>key1=value1&key2=value2</i>). */
	HTTP(SysConst.STR_WEB_REQUEST_START, SysConst.STR_WEB_REQUEST_EQUAL, SysConst.STR_WEB_REQUEST_SEPRT, 
			SysConst.STR_EMPTY),
	
	/** Parameters looks like XML file (<i>key1="value1" key2="value2"</i>). */
	XML(SysConst.STR_EMPTY, SysConst.STR_EQUAL, SysConst.STR_BLANK, SysConst.STR_EMPTY),
	
	/** Parameters looks like parameters string (<i>key1=value1,key2=value2</i>). Default value. */
	DEF(SysConst.STR_EMPTY, SysConst.STR_EQUAL, SysConst.STR_SEPRT, SysConst.STR_EMPTY);
	

	/*--------------------------------------------------------------------------------------------------------------*/
	/* Constructor
	/*--------------------------------------------------------------------------------------------------------------*/	
	
	ParamType(String prfixStr, String equalStr, String seprtStr, String prEnStr) {
		this.fPrfixStr = prfixStr; this.fEqualStr = equalStr; this.fSeprtStr = seprtStr; this.fSufixStr = prEnStr;
	}	
	
	
	/*--------------------------------------------------------------------------------------------------------------*/
	/* Private fields for store string values 
	/*--------------------------------------------------------------------------------------------------------------*/
	
	/* String that using as prefix for parameters string */
	private final String fPrfixStr;
	
	/* String that using as equal between keys and values */
	private final String fEqualStr;

	/* String that using as separator between key/value couples */
	private final String fSeprtStr;
	
	/* String that using as suffix for parameters string */
	private final String fSufixStr;
	
	/*--------------------------------------------------------------------------------------------------------------*/
	/* Method for getting default value for this enum 
	/*--------------------------------------------------------------------------------------------------------------*/	
	
	/** Get default value for this enum. The default value is <i>DEF</i>. */
	public ParamType getDef() { return ParamType.DEF; }
	
	
	/*--------------------------------------------------------------------------------------------------------------*/
	/* Methods for getting string values
	/*--------------------------------------------------------------------------------------------------------------*/	
	
	/**
	 * Get string that using as prefix for parameters string (current value).
	 * @return String that using as prefix for parameters string, now.
	 * */
	public String getPrfixStr() { return this.fPrfixStr; }
	
	/**
	 * Get string that using as equal between keys and values.
	 * 	@return String that using as equal between keys and values.
	 * */
	public String getEqualStr() { return this.fEqualStr; }	
		
	/**
	 * Get string that using as separator between key/value couples.
	 * 	@return String that using as separator between key/value couples. 
	 * */
	public String getSeprtStr() { return this.fSeprtStr; }
	
	/**
	 * Get string that using as suffix for parameters string (current value).
	 * @return String that using as suffix for parameters string, now.
	 * */
	public String getSufixStr() { return this.fSufixStr; }	
	
}
