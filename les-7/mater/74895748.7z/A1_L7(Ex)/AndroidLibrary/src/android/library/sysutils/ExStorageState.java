/*
 * Copyright (C) 2013 xDevStudio
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.   
 *  
 * */

package android.library.sysutils;

import android.os.Environment;

/**
 * Class that contains functions for a checking the state of External Storage. 
 * 
 * 	@since MEDIA_BAD_REMOVAL = "bad_removal"	
 *	@since MEDIA_CHECKING = "checking"
 *	@since MEDIA_MOUNTED = "mounted"	
 * 	@since MEDIA_MOUNTED_READ_ONLY = "mounted_ro"
 *	@since MEDIA_NOFS = "nofs"
 *	@since MEDIA_REMOVED = "removed"
 *	@since MEDIA_SHARED = "shared"
 *	@since MEDIA_UNMOUNTABLE = "unmountable"
 *	@since MEDIA_UNMOUNTED = "unmounted"
 *
 *	@author Mikhail Malakhov
 * 
 * */
public class ExStorageState {	
	
	/** 
	 * Gets the current state of External Storage.
	 * 
	 *  @return The current state of external storage.
	 *  
	 * */
	protected static String getState() {		
		return Environment.getExternalStorageState();			
	}	
	
	/** 
	 * Checks that the state of External Storage is Removed.
	 * 
	 *  @return True, if external storage is removed.
	 *   
	 * */
	public static boolean isRemoved() {
		return Environment.MEDIA_REMOVED.equals(getState());
	}	
	
	/**
	 * Checks that the state of External Storage is ReadOnly.
	 * 
	 * 	@return True, if external storage is read only.
	 *  
	 * */
	public static boolean isReadOnly() {
		return Environment.MEDIA_MOUNTED_READ_ONLY.equals(getState());
	}
		
	/**
	 * Checks that the state of External Storage is Mounted.
	 * 
	 * 	@return True, if external storage is mounted.
	 *  
	 * */
	public static boolean isMounted() {
		return Environment.MEDIA_MOUNTED.equals(getState());
	}
	
	/**
	 * Checks that the state of External Storage is Available (Mounted or 
	 * ReadOnly).
	 * 
	 * 	@return True, if external storage is available for use (mounted or 
	 * 		read only).
	 *  
	 * */	
	public static boolean isAvailable() {
		return ExStorageState.isMounted() || ExStorageState.isReadOnly(); 					
	}	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
