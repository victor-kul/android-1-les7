/*
 * Copyright (C) 2013 xDevStudio
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.   
 *  
 * */

package android.library.classes;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import android.content.Context;
import android.content.res.Resources;
import android.library.sysutils.ExStorageState;
import android.library.sysutils.SysConst;

/**
 * Class for working with dynamic array of strings. With the ability to 
 * import data from the application's resources, work with streams and save or 
 * load data from internal/external file. 
 * 
 * @author Mikhail Malakhov
 * 
 * */
public class StringList extends StringArray {

	/*  Constant from a superclass */
	private static final long serialVersionUID = 1L;
	
	/*--------------------------------------------------------------------*/
	/* Several Constructors 
	/*--------------------------------------------------------------------*/		
	
	/** Constructor without any parameters */
	public StringList() { super(); }
	
	/** Constructor with parameter from superclass */
	public StringList(int capacity) { super(capacity); }	
	
	/** 
	 * Constructor with one parameters for loading a data from Input Stream 
	 * 		@param iStream - Input Stream that contain a data
	 * */
	public StringList(InputStream iStream) { super(iStream); }
	
	/** 
	 * Constructor with two parameters for loading a data from resources 
	 * 		@param appRes - link to the application resources
	 * 		@param resID - resource ID
	 * */
	public StringList(Resources appRes, int resID) { super(appRes, resID); }
	
	/*--------------------------------------------------------------------*/
	/* Methods for working a last error message 
	/*--------------------------------------------------------------------*/	
	
	/* Field for store a last error message */
	private String mLastError = SysConst.STR_EMPTY;	
	
	/**
	 * Get a last error message.
	 * */
	public String getLastError() {
		return mLastError;
	}
	
		
	/*--------------------------------------------------------------------*/
	/* Load data
	/*--------------------------------------------------------------------*/
	
	/**
	 * Loads data to this object from internal file.
	 * 
	 * @param context the current application context
	 * @param fileName the name of internal file
	 * @param clearBefore if it is equal true, all data of this object will be 
	 * cleared before loading
	 *  
	 * @return Number of added elements or -1.
	 * 
	 * */
	public int loadFromFile(Context context, String fileName, 
			boolean clearBefore) {	

		/* Setting up return value (number of added elements) */
		int ret = -1;
		
		/* Reading all Lines from File */
		try {
			
			/* Create (and Open) a Stream for input */
			BufferedReader BR = new BufferedReader(new InputStreamReader(
					context.openFileInput(fileName)));
			
			/* Reading all Lines */
			ret = this.loadWithThrow(BR, clearBefore);
			
		} catch (IOException e) {
			mLastError = e.getMessage();
		}

		/* Return value */
		return ret;
		
	}
	
	/**
	 * Loads data to this object from external file.
	 * 
	 * @param context the current application context
	 * @param fileName the full name of external file
	 * @param clearBefore if it is equal true, all data of this object will be 
	 * cleared before loading
	 *  
	 * @return Number of added elements or -1.
	 * 
	 * */			
	public int loadFromSD(String fileName, boolean clearBefore) {
		
		/* Setting up return value (number of added elements) */
		int ret = -1;
		
		/* Checking the status of External Storage */
		if (!ExStorageState.isMounted()) {
			mLastError = SysConst.IOEX_STORAGE_NOT_AVAILABLE_MSG;
			return ret;
		}				
				
		/* Create file */
		File sdFile = new File(fileName);
		
		/* Load from file */
		try {
			
			/* Open Stream for input */			
			BufferedReader BR = new BufferedReader(new FileReader(sdFile));
			
			/* Load data from stream */
			ret = this.loadWithThrow(BR, clearBefore);
						
			
		} catch (IOException e) {
			mLastError = e.getMessage();
		}					
		
		/* Return value */		
		return ret;		
				
	}
	
	/*--------------------------------------------------------------------*/
	/* Save data
	/*--------------------------------------------------------------------*/			

	/** 
	 * Save data from this object to internal file.
	 * 
	 * @param context the current application context
	 * @param fileName the name of internal file
	 * 
	 * @return True, if operation was successfully.
	 * 
	 * */
	public boolean saveToFile(Context context, String fileName) {
		
		/* Setting up return value */
		boolean ret = true;
		
		/* Write to file */
		try {
			
			/* Create (and Open) a Stream for output */
			BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(
					context.openFileOutput(fileName, Context.MODE_PRIVATE)));
			
			/* Write to Stream */
			this.saveWithThrow(BW);
			
		} catch (IOException e) {			
			mLastError = e.getMessage();
			ret = false;			
		} 		
		
		/* Return value */		
		return ret;
	}	
	
	/** 
	 * Save data from this object to external file.
	 * 
	 * @param filePath the path of external file 
	 * @param fileName the name of external file
	 * 
	 * @return True, if operation was successfully.
	 * 
	 * */	
	public boolean saveToSD(String filePath, String fileName) {
		
		/* Setting up return value */
		boolean ret = false;
		 
		/* Checking the status of External Storage */
		if (!ExStorageState.isMounted()) {
			mLastError = SysConst.IOEX_STORAGE_NOT_AVAILABLE_MSG;
			return ret;
		}
		
		/* Create file path (directory) */
		File sdPath = new File(filePath);		
		sdPath.mkdirs();
		
		/* Create file */
		File sdFile = new File(sdPath,fileName);
		
		/* Write to file */
		try {
			
			/* Open Stream for output */
			BufferedWriter BW = new BufferedWriter(new FileWriter(sdFile));
			
			/* Write data to stream */
			this.saveWithThrow(BW);
			
			/* Setting up return code */
			ret = true;
			
		} catch (IOException e) {			
			mLastError = e.getMessage();			
		}					
		
		/* Return value */		
		return ret;
	}
	
	/** 
	 * Save data from this object to external file.
	 *  
	 * @param fullName the full name of external file
	 * 
	 * @return True, if operation was successfully.
	 * 
	 * */	
	public boolean saveToSD(String fullName) {
		
		/* Setting up return value */
		boolean ret = false;		
		
		/* Calculate a last position of "/" into fullName */		
		int p = fullName.lastIndexOf("/") + 1;
		
		/* If p value > 1, calculate names of path and file */
		if (p > 1) {
			
			/* Get a file name */
			String fileName = fullName.substring(p);
			
			/* Get a path */
			String filePath = fullName.substring(0,p);
			
			/* Save to SD file */
			ret = this.saveToSD(filePath, fileName);
			
		} else {			
			mLastError = "Wrong file name";
		}
		
		return ret;
		
	}	
		
}
