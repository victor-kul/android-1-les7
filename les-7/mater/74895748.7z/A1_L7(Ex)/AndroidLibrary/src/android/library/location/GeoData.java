package android.library.location;

import java.io.IOException;
import java.util.List;

import android.content.Context;
import android.library.classes.ContextObject;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.AsyncTask;

/**
 * Class for getting information about location. Use this class for receive 
 * information about address by location coordinates or for receive location
 * coordinates by address.  
 * */
public class GeoData extends ContextObject {
		
	/**
	 * Field for store a link to the last AsyncTaskObject object 
	 * */
	private AsyncTaskObject lastAsyncTask = null;	 
	
	/*--------------------------------------------------------------------*/
	/* Constructors
	/*--------------------------------------------------------------------*/	
			
	/**
	 * Constructs a new {@code GeoData} instance with the specified
	 * a current application context.
	 * 
	 * @param context the current application context
	 * 
	 * @throws IllegalArgumentException if context is null
	 * 
	 * */	
	public GeoData(Context context) { super(context); }
		
	/**
	 * Constructs a new {@code GeoData} instance with the specified
	 * a current application context and location provider.
	 * 
	 * @param context the current application context
	 * @param provider the location provider that will using for receive
	 * location data
	 * 
	 * @throws IllegalArgumentException if context is null
	 * 
	 * */	
	public GeoData(Context context, String provider) {		
		this(context);	
		this.setProvider(provider);
	}
	
	
	/*--------------------------------------------------------------------*/
	/* Provider properties
	/*--------------------------------------------------------------------*/	
	
	/*
	 * Private field for store a location provider.
	 * */
	private String mProvider = LocationManager.PASSIVE_PROVIDER;
		
	/**
	 * Returns current location provider.
	 * */
	public String getProvider() { return mProvider; }
		
	/**
	 * Sets a new value for location provider.
	 * */	
	public void setProvider(String provider) {
		
		/* Checking a provider (is null) */
		if (provider == null)
			throw new NullPointerException("provider == null");
		
		/* Checking a provider (is empty) */
		if (provider.length() == 0)
			throw new IllegalArgumentException("provider is empty");
			
		/* Setting up a new value for the provider */
		mProvider = provider;
			
	}
	
	/*--------------------------------------------------------------------*/
	/* Geocoder methods
	/*--------------------------------------------------------------------*/	
	
	public void getFromLocation(Location location) {
		
		/* Checking a last task object */
		if (lastAsyncTask != null) lastAsyncTask.cancel(true);
		
		/* Create a new AsyncRequestObject object */
		lastAsyncTask = new AsyncTaskObject();

		/* Execute */
		lastAsyncTask.execute(location);		
		
	}
	
	public void getFromLocation() {
		
		/* Checking a last task object */
		if (lastAsyncTask != null) lastAsyncTask.cancel(true);
		
		/* Create a new AsyncRequestObject object */
		lastAsyncTask = new AsyncTaskObject();

		/* Execute */
		lastAsyncTask.execute(new Location[] {null});		
		
	}	
	

	/*--------------------------------------------------------------------*/
	/* Asynchronous task objects
	/*--------------------------------------------------------------------*/
	
	/**
	 * Class for execute an asynchronous task
	 * */
	
	private class AsyncTaskObject extends AsyncTask<Location, Integer, 
		List<Address>> {

		/**
		 * Field for store a link to the last IOException object;  
		 * */
		private IOException mIOException = null;
		
		@Override
		protected List<Address> doInBackground(Location... params) {

			/* Setting up Exception value to null */
			mIOException = null;
			
			try {
				
				Location location = params[0]; 
				
				if (location == null)
					return GeoData.getFromLocation(getContext(), 
							getProvider(), 1);
				else
					return GeoData.getFromLocation(getContext(), location, 1);
			} catch (IOException e) {
				mIOException = e;
				return null;				
			}
		}
		
        /** 
         * This code execute after doInBackground 
         * */		
		@Override
		protected void onPostExecute(List<Address> result) {			
			IReceiveGeoDataListener listener = getReceiveGeoDataListener(); 			
			if (listener != null)
				listener.onReceiveGeoData(result, mIOException);
		}
	}	
	
	/*--------------------------------------------------------------------*/
	/* IReceiveGeoData interface
	/*--------------------------------------------------------------------*/	

	/**
	 * Interface that described onReceiveGeoData call back method.
	 * */
	public static interface IReceiveGeoDataListener {
		public void onReceiveGeoData(List<Address> data, IOException e);		
	}	
	
	/**
	 * Field for store a link to the IReceiveGeoData object.
	 * */
	private IReceiveGeoDataListener mReceiveGeoData = null;
	
	/**
	 * Returns the current IReceiveGeoDataListener object.
	 * */
	public IReceiveGeoDataListener getReceiveGeoDataListener() {
		return mReceiveGeoData;
	}
	
	/**
	 * Sets a new value for IReceiveGeoDataListener object.
	 * */
	public void setReceiveGeoDataListener(IReceiveGeoDataListener value) {
		mReceiveGeoData = value;
	}	

	
	/*--------------------------------------------------------------------*/
	/* Location service
	/*--------------------------------------------------------------------*/

	/**
     * Returns an array of Addresses that are known to describe the area 
     * immediately surrounding the given latitude and longitude. The returned 
     * addresses will be localized for the locale provided to this class's 
     * constructor.
     *
     * @param context the current application context
     * @param location the location a point for the search
     * @param maxResults max number of addresses to return
     *
     * @return A list of Address objects. Returns null or empty list if no 
     * matches were found or there is no backend service available.
     *
     * @throws IllegalArgumentException if latitude is less than -90 or 
     * greater than 90
     * @throws IllegalArgumentException if longitude is less than -180 or 
     * greater than 180
     * @throws IOException if the network is unavailable or any other I/O 
     * problem occurs
     * @throws NullPointerException if context is null, or if Location Service
     * is not available
     *  
     * */	
	public static List<Address> getFromLocation(Context context, 
			Location location, int maxResults) throws IOException {
		
		/* Checking Context value */
		if (context == null) throw new NullPointerException("Context == null");
		
		/* Checking Location value */
		if (location == null) 
			throw new NullPointerException("Location == null");
				
		/* Create Geocoder object */
		Geocoder geo = new Geocoder(context);
		
		/* Get list of places and return */
		return geo.getFromLocation(location.getLatitude(), 
				location.getLongitude(), maxResults);
		
	}	
	
	/**
     * Returns an array of Addresses that are known to describe the area 
     * immediately surrounding the given latitude and longitude. The returned 
     * addresses will be localized for the locale provided to this class's 
     * constructor.
     *
     * @param context the current application context
     * @param provider the provider that will uses as source of coordinates
     * @param maxResults max number of addresses to return
     *
     * @return A list of Address objects. Returns null or empty list if no 
     * matches were found or there is no backend service available.
     *
     * @throws IllegalArgumentException if latitude is less than -90 or 
     * greater than 90
     * @throws IllegalArgumentException if longitude is less than -180 or 
     * greater than 180
     * @throws IOException if the network is unavailable or any other I/O 
     * problem occurs
     * @throws NullPointerException if context is null, or if Location Service
     * is not available
     *  
     * */		
	public static List<Address> getFromLocation(Context context, 
			String provider, int maxResults) throws IOException {	
		
		/* Get last know location */
		Location location = LocManager.getLastKnowLocation(context, provider);
		
		/* Get list of places and return */
		return GeoData.getFromLocation(context, location, maxResults);
		
	}	

}