package android.library.location;

import android.annotation.SuppressLint;
import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;

/**
 * Class for working with Location and Location Manager objects. 
 * */
public class LocManager {
	
	/**
	 * Returns a link to the system location manager object.
	 * 
	 * @param context the current application context.
	 * 
	 * @return A link to the system location manager object or null if location
	 * manager does not exist.
	 * 
	 * @throws IllegalArgumentException if context is null 
	 * @throws NullPointerException if Location Service is not available
     * 
	 * */
	public static LocationManager getLocationManager(Context context) {
		
		/* Checking Context value */
		if (context == null) 
			throw new IllegalArgumentException("Context == null");
		
		/* Get a link to the system location manager object */
		Object locManager = context.getSystemService(Context.LOCATION_SERVICE);
		
		/* Checking the Location Manager object */
		if (locManager == null) 
			throw new NullPointerException("LocationManager == null");
		
		/* Return a value */
		return (LocationManager) locManager;
		
	}
		
	/**
	 * Returns a Location indicating the data from the last known location fix 
	 * obtained from the given provider. This can be done without starting the 
	 * provider. Note that this location could be out-of-date, for example if 
	 * the device was turned off and moved to another location.
     * 
     * <p>If the provider is currently disabled, null is returned.
     * 
     * @param context the current application context
     * @param provider the name of the provider
     * 
     * @return The last known location for the provider, or null.
     * 
     * @throws IllegalArgumentException if context is null, or if provider is 
     * null or doesn't exist
     * @throws NullPointerException if Location Service is not available
     * @throws SecurityException if no suitable permission is present for the 
     * provider 
	 * 
	 * */	
	public static Location getLastKnowLocation(Context context, 
			String provider) {		

		/* Get the last know location from provider */
		return LocManager.getLocationManager(context).getLastKnownLocation(
				provider);			
	}
	
	/**
     * Registers the {@code LocationListener} object to be notified 
     * periodically by the named provider.
     * 
     * @param context the current application context
     * @param provider the name of the provider with which to register
     * @param minTime minimum time interval between location updates, in 
     * milliseconds
     * @param minDistance minimum distance between location updates, in meters
	 * @param listener a {@code LocationListener} whose {@code 
	 * onLocationChanged} method will be called for each location update
     *
     * @throws NullPointerException if Location Service is not available
     * @throws IllegalArgumentException if provider is null or doesn't exist
     * on this device
     * @throws IllegalArgumentException if listener is null
     * @throws RuntimeException if the calling thread has no Looper
     * @throws SecurityException if no suitable permission is present for the 
     * provider
     * 
     * */	
	public static void requestLocationUpdates(Context context, long minTime, 
			float minDistance, LocationListener listener, String... providers) {		
		for (int i = 0; i < providers.length; i++)
			LocManager.getLocationManager(context).requestLocationUpdates(
					providers[i], minTime, minDistance, listener);		
	}
	
	/**
	 * Requests a single location update from the named provider.
	 * 
	 * @param context the current application context
	 * @param listener a {@code LocationListener} whose {@code 
	 * onLocationChanged} method will be called for single location update 
	 * @param provider the name of the provider with which to register 
	 * 
	 * @throws IllegalArgumentException if context is null
	 * @throws IllegalArgumentException if listener is null
	 * @throws IllegalArgumentException if provider is null 
	 * 
	 * */
	@SuppressLint("NewApi")
	protected void requestSingleUpdate(Context context, 
			LocationListener listener, String... providers) {
		for (int i = 0; i < providers.length; i++)
			LocManager.getLocationManager(context).requestSingleUpdate(
					providers[i], listener, null);		
	}	
	
    /**
     * Removes any current registration for location updates for specified 
     * {@code LocationListener} object.
     *
     * @param context the current application context
     * @param listener {@code LocationListener} object that no longer needs 
     * location updates
     * 
     * @throws IllegalArgumentException if listener is null 
     * 
     * */
	public static void removeUpdates(Context context, 
			LocationListener listener) {		
		LocManager.getLocationManager(context).removeUpdates(listener);		
	}
		
	/** 
	 * Checks whether two providers are the same.
	 * 
	 * @param providerA the name of first provider
	 * @param providerB the name of second provider
	 *  
	 * @return True, if providers are equals. 
	 *  
	 * */
	public static boolean isSameProvider(String providerA, String providerB) {	   
	    if (providerA == null || providerB == null) return false;	    
	    return providerA.equals(providerB);
	}

}














